﻿
#include <iostream>
using namespace std; 

int main()
{
    setlocale(0, "UKR"); 

    //1) Вывести на экран консоли надпись :
        cout << "\"To be \n\tor not\n\t\tto be...\"\n\t\t\t/Shakespeare/\"\n\n";
        
    //2) Вывести на экран консоли надпись 5 раз лесенкой:
        cout << "I love C++!\n\tI love C++!\n\t\tI love C++!\"\n\t\t\tI love C++!\n\t\t\t\t\I love C++!\n\n";
        
    //3) Программа показывает на экране календарь текущего месяца.
        cout << "Август 2024\t\t\t\t\/\\\t\\/\n\n";
        cout << "Пн\tВт\tСр\tЧт\tПт\tСб\tВс\n\n";
        cout << "29\t30\t31\t1\t2\t3\t4\t\n\n";
        cout << "5\t6\t7\t8\t9\t10\t11\t\n\n";
        cout << "12\t13\t14\t15\t16\t17\t18\t\n\n";
        cout << "19\t20\t21\t22\t23\t24\t25\t\n\n";
        cout << "26\t27\t28\t29\t30\t31\t1\t\n\n";
        cout << "2\t3\t4\t5\t6\t7\t8\t\n\n\n";

    //7) Вывести на экран созвездие большой медведицы.
    cout << "*\n";
    cout << "\t\t*\n\n";
    cout << "\t\t\t *\n\n";
    cout << "\t\t\t\t*\n";
    cout << "\t\t\t\t\t\t\t*\n\n\n\n";
    cout << "\t\t\t\t    *\t\t    *\n";    
}